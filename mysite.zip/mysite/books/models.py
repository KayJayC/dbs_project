from django.db import models

# Create your models here.
class Book(models.Model):
    idbooks = models.IntegerField
    title = models.CharField(max_length=200)
    author = models.CharField(max_length=70)
    ratings = models.CharField(max_length=70)
    cover = models.CharField(max_length=200, default = 'Cover Image')

    def __char__(self):
        return self.title, self.author, self.ratings, self.cover


class Barnes(models.Model):
    id = models.IntegerField
    title = models.CharField(max_length=200)
    author = models.CharField(max_length=200)
    price = models.CharField(max_length=7)
    publisher = models.CharField(max_length=200)
    genre = models.CharField(max_length=500)
    description = models.CharField(max_length=1000, default='descrip')

    def __char__(self):
        return self.title

class Amazon(models.Model):
    title = models.CharField(max_length=200)
    author = models.CharField(max_length=50)
    type = models.CharField(max_length=20)
    price = models.CharField(max_length=7)

    def __char__(self):
        return self.title

