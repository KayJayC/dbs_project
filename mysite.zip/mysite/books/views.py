from django.shortcuts import render
from .models import Book, Barnes

# Create your views here.
from django.http import HttpResponse

def all_books(request):
    books = Book.objects.all()
    barnes = Barnes.objects.all()
    return render(request, 'books.html', {'books': books, 'barnes': barnes})

def search_books(request):
    if request.method == "POST":
        searched = request.POST['searched']
        books = Book.objects.filter(title__contains=searched)
        author = Book.objects.filter(author__contains=searched)
        return render(request, 'search_books.html', {'searched':searched, 'books':books, 'author':author})
    else:
        return render(request, 'search_books.html', {})

def index(request):
    return HttpResponse("Hello, world. You're at the index.")
